# Congelador — PWA

Static, offline-first freezer inventory PWA, in Portuguese, based on `ListaCongeladorExemplo.pdf`.

## Deploy
Upload the contents of this directory to an HTTPS-enabled folder on your web host (e.g. DreamHost). Open `index.html` in a browser. On iOS use Safari > Share > Add to Home Screen. The app works offline after its first successful load.

## Usage
Tap product/category names to edit. Use `+` and `−` to adjust quantities; toggle `1`/`½` to switch increments. `×` removes an item, and the category arrows reorder categories. Use Print/PDF for A4 portrait output, and Export/Import for JSON backup.

## Important interpretation of reference
The PDF shows **every** circled digit ①–⑨ beside each item, and does not identify which numbers are marked as the actual quantity. The imported entries therefore start with quantity **zero**. The six reference items with a `½` symbol are preconfigured for half-unit increments. The full scale remains visible in print, with selected numbers bold and unselected numbers light. This interpretation can be adjusted if the paper form is meant to work differently.

## Data and limitations
Data are stored locally in browser `localStorage`, with no server transmission or accounts. Different devices do not automatically sync; export/import JSON to move data. Browser data clearing may erase the inventory. The A4 layout is designed for the reference list; very long lists may overflow one page. Check print preview before printing.

## Development
No build process or dependencies. For local development, run `python3 -m http.server 8080` in this directory, then open http://localhost:8080. Service workers require HTTPS or localhost.

## Aligned sections (v0.2)
Categories are arranged in synchronized left/right pairs. Every pair shares the height of its tallest category, so the horizontal separators stay aligned after items are added or deleted on either side. This also applies to the A4 print layout. Use **Imprimir / PDF** and select **Save as PDF** in the browser print dialog. If the list exceeds one page, the app warns before printing; the print layout is intentionally one A4 page and excess content may be clipped.
